# Crate cloudflare apps integration

![Demo](https://i.imgur.com/B3AKkRG.gif)
