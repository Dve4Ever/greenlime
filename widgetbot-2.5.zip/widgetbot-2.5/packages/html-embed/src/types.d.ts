export interface API extends HTMLIFrameElement {
  on: Function
}
