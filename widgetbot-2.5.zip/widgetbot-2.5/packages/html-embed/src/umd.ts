import WidgetBot from '.'

const widgetbot = new WidgetBot()

export default widgetbot
