// import { Translation } from '..'

// const translation: Translation = {
//   'message.join_message': `Hey! Listen! {name} has joined!`,
//   'message.channel': `Message {channel}`,
//   'header.join': `Join`
// }

// export default translation
