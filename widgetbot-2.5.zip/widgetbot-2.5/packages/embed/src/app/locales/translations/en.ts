const translation = {
  'message.join_message': `{name} has joined. Stay a while and listen!`,
  'message.channel': `Message {channel}`,
  'header.join': `Join`
}

export default translation
