import styled from 'react-emotion'
import * as Modal from '@ui/Modal'

export const Content = styled(Modal.Content)`
  padding: 24px 32px;
`
