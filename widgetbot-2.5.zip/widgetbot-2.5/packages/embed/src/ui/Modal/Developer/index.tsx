export { default as Sam } from './samdd'
