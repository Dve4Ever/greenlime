import * as React from 'react'

import { Spinner } from './elements'

const Loading = () => <Spinner className="loading" />

export default Loading
