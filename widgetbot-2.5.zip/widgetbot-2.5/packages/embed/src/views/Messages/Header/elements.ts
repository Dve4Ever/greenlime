import styled from '@lib/emotion'
import Header from '@ui/Header'

export const Root = styled(Header)``
