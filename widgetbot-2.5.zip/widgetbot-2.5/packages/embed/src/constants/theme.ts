export const THEME_COLOR_PRIMARY = '#fff'
export const THEME_COLOR_ACCENT = '#7289da'
export const THEME_BACKGROUND = '#36393E'
