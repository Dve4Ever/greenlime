import * as path from 'path'

export const generated = path.join(__dirname, '../../../../__generated__')
