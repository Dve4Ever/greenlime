/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: SidebarVisibility
// ====================================================

export interface SidebarVisibility_sidebar {
  __typename: 'Sidebar'
  open: boolean
}

export interface SidebarVisibility {
  sidebar: SidebarVisibility_sidebar
}
