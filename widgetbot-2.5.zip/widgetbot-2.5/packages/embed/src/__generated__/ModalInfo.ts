/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: ModalInfo
// ====================================================

export interface ModalInfo_modal {
  __typename: 'Modal'
  open: boolean
  type: string | null
  data: string | null
}

export interface ModalInfo {
  modal: ModalInfo_modal
}
