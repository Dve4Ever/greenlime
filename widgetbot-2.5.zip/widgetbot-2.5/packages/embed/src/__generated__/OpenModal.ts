/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: OpenModal
// ====================================================

export interface OpenModal {
  openModal: boolean | null
}

export interface OpenModalVariables {
  type: string
  data?: string | null
}
