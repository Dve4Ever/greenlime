/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: Locale
// ====================================================

export interface Locale_locale {
  __typename: 'Locale'
  language: string
  translations: (string[] | null)[]
}

export interface Locale {
  locale: Locale_locale
}
