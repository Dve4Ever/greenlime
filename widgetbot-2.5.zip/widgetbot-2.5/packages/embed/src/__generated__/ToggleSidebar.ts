/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: ToggleSidebar
// ====================================================

export interface ToggleSidebar {
  toggleSidebar: boolean
}

export interface ToggleSidebarVariables {
  open?: boolean | null
}
