/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: CloseModal
// ====================================================

export interface CloseModal {
  closeModal: boolean | null
}
