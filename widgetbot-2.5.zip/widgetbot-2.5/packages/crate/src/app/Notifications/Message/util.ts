export const defaultAvatar = `https://cdn.discordapp.com/embed/avatars/0.png`
