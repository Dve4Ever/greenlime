declare namespace JSX {
  interface IntrinsicElements {
    'shadow-root': any
    'shadow-styles': any
  }
}
