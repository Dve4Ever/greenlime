enum Messages {
  EMBED_API_INVOCATION = 'Something went wrong! failed to connect to @widgetbot/embed-api!'
}

export default Messages
